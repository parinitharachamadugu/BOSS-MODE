export class UserComponent {
    constructor(
        public id: number,
        public username: string,
        public password: string
    ) { }
}
