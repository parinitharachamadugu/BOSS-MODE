"""Package level init."""

__version__ = '0.0.2'
